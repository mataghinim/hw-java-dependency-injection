package org.example.infrastructure.annotation;

public enum ScopeType {
    SINGLETON,
    PROTOTYPE
}
